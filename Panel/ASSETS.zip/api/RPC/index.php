Hahah still hunt dumb dog, try harder :), This is logged now!?


<script>
	atob("SSBmdWNrIHlvdXIgbW90aGVy");
</script>
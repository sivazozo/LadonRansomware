<?php

die(header("Location:https://pornhub.com/"));
?>